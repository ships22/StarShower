import utils from './utils'

const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')
var s = "here";
canvas.width = innerWidth
canvas.height = innerHeight
const colors = ['#2185C5', '#7ECEFD', '#FFF6E5', '#FF7F66']

// Event Listeners


addEventListener('resize', () => {
    canvas.width = innerWidth
    canvas.height = innerHeight
    init()
})

// Objects
function Star(x, y, radius, color) {
    this.x = x
    this.y = y
    this.radius = radius
    this.color = color
    this.velocity = {
        x : (Math.random() - 0.5) * 8,
        y : 3
    }
    this.gravity = 1
    this.fraction = .8
}

Star.prototype.draw = function() {
    c.save();
    c.beginPath()
    c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
    c.shadowColor = '#e3eaef';
    c.shadowBlur  = 20;
    c.fillStyle = this.color;
    c.fill();
    c.closePath();
    c.restore();
}

Star.prototype.update = function() {
    this.draw()
    if(this.y + this.radius + this.velocity.y > canvas.height - groundHeight){
        this.velocity.y = -this.velocity.y * this.fraction;
        this.splitter();
    }else{
        this.velocity.y += this.gravity;
    };
    if (this.x + this.velocity.x + this.radius > canvas.width || this.x - this.radius <= 0) {
        this.velocity.x = -this.velocity.x * this.fraction;
        this.splitter();
    }
    this.x += this.velocity.x;
    this.y += this.velocity.y;
}

Star.prototype.splitter = function(){
    console.log('Splits...')
    this.radius -= 3;
    for(let i = 0; i < 8; i++){
        ministars.push(new MiniStar(this.x, this.y, 2));
    }
    console.log(ministars);
}

// creating ministars

function MiniStar(x, y, radius, color){
    Star.call(this, x, y, radius, color)
    this.velocity = {
        x : utils.randomIntFromRange(-5, 5),
        y : utils.randomIntFromRange(-15, 15)
    }
    this.gravity  = 0.1
    this.fraction = 0.8
    this.ttl      = 200
    this.opacity  = 1 
}
MiniStar.prototype.draw = function() {
    c.save();
    c.beginPath();
    c.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
    c.fillStyle = `rgba(227, 234, 239, ${this.opacity})`;
    c.shadowColor = '#e3eaef';
    c.shadowBlur  = 20;
    c.fill();
    c.closePath();
    c.restore();
}

MiniStar.prototype.update = function() {
    this.draw();
    if(this.y + this.radius + this.velocity.y > canvas.height - groundHeight){
        this.velocity.y = -this.velocity.y * this.fraction;
    }else{
        this.velocity.y += this.gravity;
    };
    this.x += this.velocity.x;
    this.y += this.velocity.y;
    this.ttl -= 1;
    this.opacity -= 1 / this.ttl;
}

// Creating mountains at the back
function createMountain(mountainNumber, height, color){
    for (let i = 0; i < mountainNumber; i++) {
        const mountainWidth = canvas.width / mountainNumber;
        c.beginPath();
        c.moveTo(i * mountainWidth, canvas.height);
        c.lineTo(i * mountainWidth + mountainWidth + 325, canvas.height);
        c.lineTo(i * mountainWidth + mountainWidth / 2, canvas.height - height);
        c.lineTo(i * mountainWidth - 325, canvas.height);   
        c.fillStyle = color;
        c.fill();
        c.closePath();
        
    }
};


// Implementation 
const background = c.createLinearGradient(0, 0, 0, canvas.height);
background.addColorStop(0, '#0B0B3B');
background.addColorStop(1, '#3f586B');
let stars;
let ministars;
let backStars;
let ticker = 0;
let randomSpawn = 75;
let groundHeight = 100;
function init() {
    stars     = [];
    ministars = [];
    backStars = [];
    for (let i = 0; i < 180; i++) {
        let x = Math.random() * canvas.width;
        let y = Math.random() * canvas.height;
        let radius = Math.random() * 3;
            backStars.push(new Star(x, y, radius, 'white'));   
    }
    
}

// Animation Loop
function animate() {
    requestAnimationFrame(animate);
    c.fillStyle = background;
    c.fillRect(0, 0, canvas.width, canvas.height);
    backStars.forEach(backStar => {
        backStar.draw();
    });
    createMountain(1, canvas.height - 80, '#0A0A2A');
    createMountain(2, canvas.height - 220, '#0B0B3B');
    createMountain(3, canvas.height - 390, '#101056');
    c.fillStyle = '#0A0A2A';
    c.fillRect(0, canvas.height - groundHeight, canvas.width, groundHeight);
    
    stars.forEach((star, index) => {
        star.update();
        if (star.radius == 0) {
            stars.splice(index, 1);
        }
    });
    ministars.forEach( (miniStar, index) =>{
        miniStar.update();
        if (miniStar.ttl == 0) {
            ministars.splice(index, 1);
        }
    });
    ticker++;
    if (ticker % randomSpawn == 0) {
        const radius = 12;
        const x = Math.max(radius, Math.random() * canvas.width - radius);
        stars.push(new Star(x, -100, radius, 'white'));
        randomSpawn = utils.randomIntFromRange(75, 100);
        
    }
}

init()
animate()
